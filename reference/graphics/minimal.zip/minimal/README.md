# Reference: Minimal Graphic

This is a minimal implementation of a Graphic.
